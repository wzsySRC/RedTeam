<footer class="footer">
<center>
  <div class="container2">
    <center><p class="text-muted">
        <a href="https://twitter.com/xploresec"><img src="img/twitter-32.png" style="width:20px; height:20px;"></a>
        &nbsp;<font size=2>PowerShell Empire Web v2.0</font>&nbsp;
        <a href="https://github.com/interference-security/empire-web/"><img src="img/github-32.png" style="width:20px; height:20px;"></a>
    </p></center>
  </div>
  </center>
</footer>
