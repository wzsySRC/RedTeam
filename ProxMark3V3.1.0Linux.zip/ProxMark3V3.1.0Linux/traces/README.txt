em4102-clamshell.pm3: Samy's clamshell EM4102 tag (ID: 1f00d9b3a5)
em4102-thin.pm3: Samy's thin credit-card style EM4102 tag (ID: 1a0041375d)
EM4102-1.pm3: credit card style card EM4102 tag (ID: 010872e77c)
EM4102-2.pm3: credit card style card EM4102 tag (ID: 010872beec)
EM4102-3.pm3: credit card style card EM4102 tag (ID: 010872e14f)
em4x05.pm3: ear tag FDX-B ISO-11784/5 (ID: 6DB0840800F80001 - Application Identifier:  8000, Country Code:  124 (Canada), National ID:  270601654)
em4x50.pm3: credit card style card EM4x50 tag (ID: DE2A3F00)
hid-proxCardII-05512-11432784-1.pm3: clamshell-style HID ProxCard II card
indala-00002-12345678-1A: Indala credit-card style card
homeagain.pm3: HomeAgain animal (cat) tag - ID 985121004515220
homeagain1600.pm3: HomeAgain animal (cat) tag - ID 985121004515220
keri.pm3: Keri PSK-3 Key Ring tag (back of tag: 1460 3411)
Transit999-best.pm3: Transit 999 format (UID 99531670)

The files 'modulation-'... are all encoded with identical data (hex 00 01 02 03 04 05 06 07 08 09 0A 0B)
for the purpose of recognition and testing of demodulation schemes. They were created by writing Q5 tags
appropriately configured. The raw data is in 'modulation-data.dat'.

ata5577-HIDemu-FC1-C9.pm3: ata5577 in hid prox 26 bit emulation facility code:1 card#:9
casi-12ed825c29.pm3: casi rusco 40 bit (EM410x ID: 12ed825c29)
EM4102-Fob.pm3: (ID: 0400193cbe)
ioprox-XSF-01-3B-44725.pm3: IO Prox FSK RF/64 ID in name
ioprox-XSF-01-BE-03011.pm3: IO Prox FSK RF/64 ID in name
indala-504278295.pm3: PSK 26 bit indala
AWID-15-259.pm3: AWID FSK RF/50 FC: 15 Card: 259 
HID-weak-fob-11647.pm3: HID 32bit Prox Card#: 11647.  very weak tag/read but just readable.