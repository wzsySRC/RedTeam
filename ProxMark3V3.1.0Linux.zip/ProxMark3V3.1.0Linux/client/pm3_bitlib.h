#ifndef PM3_BITLIB
#define PM3_BITLIB

#include <lua.h>
int set_bit_library (lua_State *L);

#endif /* PM3_BITLIB */
