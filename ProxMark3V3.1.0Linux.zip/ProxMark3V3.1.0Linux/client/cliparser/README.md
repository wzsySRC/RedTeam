# Command line parser

cliparser - librari for proxmark with command line parsing high level functions.

## External libraries:

### argtable

Argtable3 is a single-file, ANSI C, command-line parsing library that parses GNU-style command-line options.

You can download argtable3 from this repository https://github.com/argtable/argtable3

[argtable3 license](https://github.com/argtable/argtable3/blob/master/LICENSE)
