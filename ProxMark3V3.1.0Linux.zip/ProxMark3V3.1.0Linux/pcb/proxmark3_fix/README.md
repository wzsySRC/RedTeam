Corrected Eagle layout files and re-generated CAM files. DRC checked (via eurocircuits.com 's PCB visualizer too) no problems found, ready to production!

Please find the change list in the CAD folder text file.